package coffee.syntax;

/**
 * Created by ft on 10/8/15.
 */
public class Operators {
    public static final String PLUS = "+";
    public static final String MINUS = "-";
    public static final String SLASH = "/";
    public static final String ASTERISK = "*";
    public static final String LEFT_PARENTHESIS = "(";
    public static final String RIGHT_PARENTHESIS = ")";
}
