package coffee.project;

import coffee.REPL;

/**
 * Created by ft on 10/14/15.
 */
public class Lexer implements REPL.LineInputCallback {
    @Override
    public String lineInput(String line) {
        try {
            throw new NoSuchMethodException("Lexer is not implemented.");
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }
}
